package com.javafx.librarian.controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class AddTacGiaController implements Initializable {
    @FXML
    public TextField txtAddMaTacGia;
    @FXML
    public TextField txtAddTenTacGia;
    @FXML
    public Button btnAddThem;
    @FXML
    public Button btnAddDong;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

}
