package com.javafx.librarian.utils;

public class Util {
    public static final String URL_JDBC = "jdbc:mysql://localhost:3306/qltv?useUnicode=yes&characterEncoding=UTF-8&serverTimezone=UTC";
    public static final String USERNAME_JDBC = "root";
    public static final String PASSWORD_JDBC = "";

}
